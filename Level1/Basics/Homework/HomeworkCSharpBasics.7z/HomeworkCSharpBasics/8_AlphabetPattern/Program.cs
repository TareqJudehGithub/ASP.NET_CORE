﻿
namespace _8_AlphabetPattern
{
    internal class Program
    {
        static void Main(string[] args)
        {

        }
    }
}
