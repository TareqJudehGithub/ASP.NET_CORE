﻿using System;

namespace CharAndStringTypes
{
    class Program
    {
        static void Main(string[] args)
        {

        }
    }
}
