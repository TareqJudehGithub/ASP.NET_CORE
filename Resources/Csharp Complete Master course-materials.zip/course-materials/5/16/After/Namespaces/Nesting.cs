// namespace Namespace1.Namespace2
// {
//     class Type1 { }

//     struct Type2 { }
// }

namespace Namespace1
{
    namespace Namespace2
    {
        class Type1 { }

        struct Type2 { }
    }
}