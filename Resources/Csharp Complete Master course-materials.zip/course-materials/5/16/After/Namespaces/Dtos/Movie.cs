namespace Dtos
{
    public class Movie
    {

    }
}