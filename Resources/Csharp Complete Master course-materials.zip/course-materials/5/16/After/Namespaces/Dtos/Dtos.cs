// namespace Dtos
// {
//     public class Actor
//     {

//     }

//     public class Movie
//     {

//     }
// }