namespace Dtos
{
    public class Actor
    {
        
    }
}