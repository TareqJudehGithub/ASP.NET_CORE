// Bad practice
public class Global
{
    
}