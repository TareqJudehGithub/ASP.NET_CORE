namespace Entities
{
    public class Movie
    {

    }
}