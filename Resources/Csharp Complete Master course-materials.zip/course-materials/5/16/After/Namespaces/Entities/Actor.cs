namespace Entities
{
    public class Actor
    {
        
    }
}