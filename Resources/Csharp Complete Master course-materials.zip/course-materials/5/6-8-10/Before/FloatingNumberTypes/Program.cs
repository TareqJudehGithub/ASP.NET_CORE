﻿using System;

namespace FloatingNumberTypes
{
    class Program
    {
        static void Main(string[] args)
        {

        }
    }
}
