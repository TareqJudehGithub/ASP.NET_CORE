﻿using System;

namespace Booleans
{
    class Program
    {
        static void Main(string[] args)
        {
            
        }
    }
}
