﻿using System;

namespace IntegersTypes
{
    class Program
    {
        static void Main(string[] args)
        {
                             
        }
    }
}
