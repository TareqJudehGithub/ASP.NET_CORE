namespace Events
{
    internal class Service1
    {
        internal void DoSomeWork(int workItemId)
        {
            
        }
        private void OnWorkDone(int workItemId)
        {
            
        }
    }
}