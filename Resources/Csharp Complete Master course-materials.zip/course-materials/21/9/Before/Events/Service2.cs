namespace Events
{
    internal class Service2
    {
        internal void DoSomeWork(int workItemId)
        {
            
        }
        private void OnWorkDone(int workItemId)
        {
            
        }
    }
}