namespace Events
{
    internal delegate void WorkDoneHandler(int workItemId);
}