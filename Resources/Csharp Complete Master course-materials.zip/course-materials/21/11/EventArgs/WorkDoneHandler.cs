namespace Events
{
    internal delegate void WorkDoneHandler(object sender, WorkDoneEventArgs eventArgs);
}