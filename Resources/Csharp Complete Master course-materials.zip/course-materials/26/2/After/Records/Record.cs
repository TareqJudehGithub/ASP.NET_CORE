namespace Records
{
    public record Movie(int Id,string Title,string Description);
}