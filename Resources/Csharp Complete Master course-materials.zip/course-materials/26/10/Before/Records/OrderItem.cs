namespace Records
{
    public record OrderItem(int Id, string ProductCode, int Quantity);
}