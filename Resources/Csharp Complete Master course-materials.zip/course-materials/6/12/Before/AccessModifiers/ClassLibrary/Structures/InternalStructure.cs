namespace ClassLibrary.Structures
{
    
}