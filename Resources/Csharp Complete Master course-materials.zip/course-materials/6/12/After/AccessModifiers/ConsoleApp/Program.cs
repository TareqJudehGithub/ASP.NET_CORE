﻿using System;
using ClassLibrary.Classes;
using ClassLibrary.Structures;

namespace ConsoleApp
{
    class Program
    {
        static void Main(string[] args)
        {

        }
    }
}