namespace MyNamespace
{
    public class MyClass
    {
        private protected class MyInnerClass
        {
            
        }
    }

    public struct MyStruct
    {
        private struct MyInnerStruct
        {
            
        }
    }
}