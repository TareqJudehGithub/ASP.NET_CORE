using System;

namespace ObserverPattern
{
    // The observer class may be generic or not 
    public class Observer
    {
        // Add a private name field 

        // a constructor must initialize the name 
        // field

        // Create a notify method that can be generic
    }
}