namespace ObserverPattern
{
    // This interface must be generic
    public interface IObservable
    {
        // Try to find the methods of the observable
        // to abstract the behavior of the Observable class
    }
}