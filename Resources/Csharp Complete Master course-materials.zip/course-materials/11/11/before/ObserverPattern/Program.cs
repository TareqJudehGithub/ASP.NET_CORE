﻿using System;
using System.Timers;

namespace ObserverPattern
{
    class Program
    {
        // Instantiate your observable class here
        static void Main(string[] args)
        {
            // Create your observers and subscribe
            // tip 1 : use the Timer class to change the value
            // of the subject every second (see documentation)

            // tip 2 : start the timer inside of an infinite
            // while loop
        }

    }
}
