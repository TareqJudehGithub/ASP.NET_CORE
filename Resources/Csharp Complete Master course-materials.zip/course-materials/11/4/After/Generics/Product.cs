namespace Generics
{
    internal class Product
    {
    }
}