﻿using System;
using System.Timers;

namespace ObserverPattern
{
    class Program
    {
        static void Main(string[] args)
        {
            
        }
    }
}
