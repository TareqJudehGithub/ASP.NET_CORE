﻿using System;

namespace Generics
{
    class Program
    {
        static void Main(string[] args)
        {
            
        }
    }
}
