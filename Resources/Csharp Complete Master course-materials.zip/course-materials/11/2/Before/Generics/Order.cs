namespace Generics
{
    internal class Order
    {
        
    }
}