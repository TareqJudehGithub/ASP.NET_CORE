namespace Generics
{
    internal class OrderItem
    {
        
    }
}