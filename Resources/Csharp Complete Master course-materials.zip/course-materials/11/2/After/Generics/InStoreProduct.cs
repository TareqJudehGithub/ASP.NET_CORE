namespace Generics
{
    internal class InStoreProduct : Product
    {
        // specific members
        public int StoreId { get; set; }
    }
}