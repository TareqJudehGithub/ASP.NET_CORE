namespace Generics
{
    internal class OnlineProduct : Product
    {
        // Specific members
        public string ShippingOption { get; set; }
    }
}