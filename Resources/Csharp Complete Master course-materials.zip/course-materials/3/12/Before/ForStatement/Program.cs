﻿using System;

namespace ForStatement
{
    class Program
    {
        static void Main(string[] args)
        {
            
        }
    }
}
