﻿using System;

namespace DoWhileStatement
{
    class Program
    {
        static void Main(string[] args)
        {

        }
    }
}
