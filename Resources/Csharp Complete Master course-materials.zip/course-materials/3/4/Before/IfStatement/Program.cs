﻿using System;

namespace IfStatement
{
    class Program
    {
        static void Main(string[] args)
        {

        }
    }
}
