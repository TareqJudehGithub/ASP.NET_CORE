﻿using System;

namespace WhileStatement
{
    class Program
    {
        static void Main(string[] args)
        {
            
        }
    }
}
