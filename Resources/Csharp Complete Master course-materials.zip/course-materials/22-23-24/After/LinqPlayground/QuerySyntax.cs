namespace LinqPlayground
{
    public enum QuerySyntax
    {
        Query,
        Method
    }
}