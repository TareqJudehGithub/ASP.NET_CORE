using System;

namespace ImplementIComparable
{
    public class SuperHero
    {
        
    }

}