using System;

namespace ImplementIComparable
{
    public static class SuperHeroRatingCalculator
    {
         
    }
}