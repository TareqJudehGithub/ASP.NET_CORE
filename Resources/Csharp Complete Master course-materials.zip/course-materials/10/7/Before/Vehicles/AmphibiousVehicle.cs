using System;

namespace Vehicles
{
    public class AmphibiousVehicle
    {
        
    }
}