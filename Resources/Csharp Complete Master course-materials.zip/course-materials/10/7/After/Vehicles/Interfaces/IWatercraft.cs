namespace Vehicles
{
    public interface IWatercraft
    {
        void MoveForward();
    }
}