namespace Vehicles
{
    public interface ILandVehicle
    {
        void MoveForward();
    }
}