namespace InterfacesExamples
{
    class JsonLogger
    {

    }
}