namespace InterfacesExamples
{
    class TextLogger
    {

    }
}