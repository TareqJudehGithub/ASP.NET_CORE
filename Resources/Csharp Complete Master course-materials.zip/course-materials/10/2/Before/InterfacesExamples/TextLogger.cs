namespace InterfacesExamples
{
    class TextLogger
    {
        
    }
}