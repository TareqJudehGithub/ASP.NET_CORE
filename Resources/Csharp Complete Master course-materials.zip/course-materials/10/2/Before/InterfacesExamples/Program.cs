﻿using System;

namespace InterfacesExamples
{
    class Program
    {
        static void Main(string[] args)
        {
            
        }
    }
}
