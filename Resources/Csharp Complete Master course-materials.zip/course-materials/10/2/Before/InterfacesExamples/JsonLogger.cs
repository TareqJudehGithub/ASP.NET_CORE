namespace InterfacesExamples
{
    class JsonLogger
    {
        
    }
}