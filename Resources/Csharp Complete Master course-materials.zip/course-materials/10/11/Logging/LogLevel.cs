namespace Logging.Entities
{
    public enum LogLevel
    {
        INFORMATION,
        ERROR
    }
}