namespace Logging.Entities
{
    public enum FileType
    {
        TXT = 1,
        JSON = 2
    }
}