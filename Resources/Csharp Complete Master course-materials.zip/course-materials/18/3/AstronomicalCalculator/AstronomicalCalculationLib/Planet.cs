namespace AstronomicalCalculationLib
{
    internal class Planet
    {
        public string Name { get; set; }
        public double Mass { get; set; }
        public double Radius { get; set; }
    }
}