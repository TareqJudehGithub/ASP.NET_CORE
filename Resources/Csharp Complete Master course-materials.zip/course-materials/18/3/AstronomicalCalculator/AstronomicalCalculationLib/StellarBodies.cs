namespace AstronomicalCalculationLib
{
    public enum Stars
    {
        Sun,
        R136A1
    }
    public enum Planets
    {
        Mercury,
        Venus,
        Earth,
        Mars,
        Jupiter,
        Saturn,
        Uranus,
        Neptune    
    }

    public enum Satellites
    {
        Moon,
        Europa
    }
}