﻿using System;

namespace ShowCompileRuntimeErrors
{
    class Program
    {
        static void Main(string[] args)
        {
            int int1 = 1;
            int int2 = 0;
            int int3 = int1/int2;
        }
    }
}
