﻿using System;

namespace Variables
{
    class Program
    {
        static void Main(string[] args)
        {

        }
    }
}
