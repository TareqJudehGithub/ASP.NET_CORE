﻿using System;

namespace Blocks
{
    class Program
    {
        static void Main(string[] args)
        {

        }
    }
}