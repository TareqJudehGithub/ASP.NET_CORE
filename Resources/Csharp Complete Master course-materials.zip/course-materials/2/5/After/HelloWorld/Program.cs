﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace HelloWorld
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Hello World!");
            var from = new List<int>();
            var query = from item in @from
                        select item;
        }
    }
}
