﻿using System;

namespace RingBuffer
{
    class Program
    {
        static void Main(string[] args)
        {
            
        }
    }
}
